
/*
 * You can modify this sign to disguise your encrypt file
 */
char encrypt_file_header_sign[] = {
	0xe2, 0x16, 0xb5, 0x1e,
	0xf3, 0x2b, 0x10, 0xef
};

int encrypt_file_header_length = sizeof(encrypt_file_header_sign);
