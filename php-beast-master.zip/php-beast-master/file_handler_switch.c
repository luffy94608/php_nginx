
char *file_handler_switch = "tmpfile";
